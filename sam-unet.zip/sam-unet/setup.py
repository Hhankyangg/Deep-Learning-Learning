from setuptools import find_packages, setup

setup(
    name="sam-unet",
    version="0.1",
    author="Hank Yang",
    python_requires=">=3.10",
    packages=["sam_unet"]
    )