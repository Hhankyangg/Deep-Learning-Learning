config_dict = {
    'data_directory': '/home/shyang/Dataset/160k/',
    # 'data_directory': '/home/shyang/code/avp-sam/avp_sam/data_demo',
    'random_seed': 000000,
    'checkpoint_path': '/home/hankyang/WorkShop/sam-unet/sam_unet/pretrained/sam_vit_b_01ec64.pth',
    'img_size': 256,
    'pixel_mean': [123.675, 116.28, 103.53],
    'pixel_std': [58.395, 57.12, 57.375],
    'work_dir': "workdir",
}
